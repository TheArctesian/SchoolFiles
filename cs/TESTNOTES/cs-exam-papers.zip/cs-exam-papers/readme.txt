Converting PDF to HTML
----------------------

PDF Online
----------
This site does a decent conversion, but there things that have to be corrected; some images and some special characters.
http://www.pdfonline.com/convert-pdf-to-html/
The conversion results in a single html file; earlier versions of this tool resulted in lots of files.

1. edit index.html: add links to the papers
   for example:
   <a href="papers/2016-May-P1-SL/M16-P1-SL.html">SL</a>
      
2. edit markschemes: add the named anchor for each question
   <a name="q1"></a>
   put the anchor in front of the question number.
   
3. edit papers: for each question, add a named anchor, plus a link to the markscheme
   <a name="q1"></a><a href="../../markschemes/2016-May-MS-P1-HL/M16-P1-HL-MS.html#q1">MS</a>

4. edit index.html: for each affected topic, add the links to the test questions
   <a href="papers/2016-May-P1-HL/M16-P1-HL.html#q1">M16-P1-Q1</a> &nbsp;
       
5. For paper2, edit the title page: add a link to each option:
   <a href="#optionA">...</a>
   <a name="optionA"></a>
   same for B,C,D


Adobe Acrobat
-------------

Does a crap job. Do not use it.


Zamzar
------
http://www.zamzar.com/
does a perfect conversion, but I could not get the additional html to work; links from questions to markscheme do not work.


IntraPDF
--------
Note: Looks like IntraPDF has not been updated since 2006. No OSX version?

1. run IntraPDF
   Start > All Programs > IntraPDF > Advanced > PDF to HTML

2. HTML Options > Frames and navigation > No frames

3. File and folders > Add PDF document

4. Start conversion

5. The tool will create a folder.
   Move the folder to the HTML-version website folder

6. Compare the resulting html (for the paper & markscheme) to the PDF
   Fix any quirks.

7. Add named anchors to the markscheme html file

8. Add hyperlinks from the paper html to the markscheme html

9. Edit index.html
   Add a link to each quesion in the paper html.
